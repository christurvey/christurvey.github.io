'use strict';
//Written by Christopher J. Turvey 11/25/2019
//Puppeteer uploading dart audio... 
//TODO: move credentials
//TODO: make propper command like "node dartdirectory.js <director ending in a slash >"
//TODO: Send to Dr. Evans for future input
const puppeteer = require('puppeteer');
const devices = require('puppeteer/DeviceDescriptors');
var fs = require('fs');
//const fsPromise = fs.promises;
//const fs = require("fs");
const util = require('util');
const username = 'YOU-USERNAME'; //TODO Make part of process.env... FOR NOW CHANGE THIS!!!
const password = 'YOUR PASSWORD'; //TODO Make part of process.env... FOR NOW CHANGE THIS!!!
const readdir = util.promisify(fs.readdir);


(async () => {
    console.log('Start')
    if (process.argv.length <= 2) {
        console.log("Usage: node " + __filename + " /path/to/directory");
        process.exit(-1);
    }

    const browser = await puppeteer.launch({
        headless: true, // launch headful mode
        slowMo: 50, // slow down puppeteer script so that it's easier to follow visually
    })

    const page = await browser.newPage()
    await page.setDefaultNavigationTimeout(0);
    await page.setDefaultTimeout(0);
    console.log("1. Starting up...");
    const navigationPromise = page.waitForNavigation()

    await page.goto('https://sepaldart.herokuapp.com/')

    await page.setViewport({
        width: 1721,
        height: 1017
    })
    console.log("2. Logging in...");
    await page.waitForSelector('.col-md-4 #user_session_email')
    await page.click('.col-md-4 #user_session_email')
    await page.keyboard.type(username);

    await page.waitForSelector('.col-md-4 #user_session_password')
    await page.click('.col-md-4 #user_session_password')
    await page.keyboard.type(password);

    await page.waitForSelector('.row > .col-md-4 > .login-dialog > #login > .btn')
    await page.click('.row > .col-md-4 > .login-dialog > #login > .btn')

    await navigationPromise

    console.log("3. Logged in... ");
    //  await navigationPromise



    var path = process.argv[2];
    console.log(path);
    let inpath = path;
    //await items = await readdir(inpath);
    let items;
    try {
        items = await readdir(inpath);

    } catch (e) {
        console.log('e', e);
    }
    console.log(items);
    console.log('Before Start... Looping Items');
    //const forLoop = async _ => {
    console.log('Start');
    //for (var i=0; i<items.length; i++) {
    for (const item of items) {


        if (item.indexOf('.mp3') != -1) {
            var nameSplit = item.split('.');
            console.log(nameSplit[0]);
            let fileNoExtension = nameSplit[0];
            if (fs.existsSync(inpath+fileNoExtension + '.pdf')) {
                console.log('Output Exists... Skipping... sorry...' );
            } else {
                console.log(item);

                //await dartIt(path, nameSplit[0])

                await page.goto('https://sepaldart.herokuapp.com/dart_audio/new');

                await page.waitForSelector('.row > #dropzone > #upload-instructions > label > b')
                // await page.click('.row > #dropzone > #upload-instructions > label > b')

                // await page.waitForSelector('.row > #dropzone > #upload-instructions #drag-ok')
                //  await page.click('.row > #dropzone > #upload-instructions #drag-ok')
                console.log("4... Opening a file Chooser window...");
                const [fileChooser] = await Promise.all([
                    page.waitForFileChooser(),
                    page.click('label[for=dart_audio_file]'), // some button that triggers file selection

                ]);

                console.log("5... Uploading the file...");
                //await fileChooser.accept(['/Users/christurvey/Google\ Drive/hero-horizon/Voice\ Over/VO/6_hint.mp3']);

                await fileChooser.accept([inpath + fileNoExtension + ".mp3"]);

                console.log("6... Waiting for the upload to happen... or");
                //await page.waitForNavigation();
                //  //await navigationPromise

                console.log("7... Waiting Part 2! For the Graph to load in");
                // await  page.waitForNavigation({ waitUntil: 'networkidle0' })
                //await navigationPromise
                //await navigationPromise
                await page.waitForSelector('#waveform-plot');
                try {


                    await page.pdf({
                        path: inpath + fileNoExtension + ".pdf",

                        format: "A4",
                        printBackground: true
                    })
                } catch (err) {
                    await page.screenshot({
                        path: inpath + fileNoExtension + '.png',
                        fullPage: true
                    });
                }

                console.log("8... Graph loaded and files saved... Thanks for using DartPuppet");

            }
        }
    };
    await browser.close()
})();